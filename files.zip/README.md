# 🛡 Loyiha Nazorat Bot

Telegram kanalingizdagi loyihalarni (saytlar, API'lar) doimiy ravishda tekshirib,
xato yoki uzilish bo'lsa avtomatik kanalga xabar beradigan bot.

## ✨ Imkoniyatlari

- 🔍 Har `N` daqiqada barcha loyihalarni avtomatik tekshiradi (sozlanadigan)
- 🔴 Sayt ishlamay qolsa (404, 500, ulanish xatosi, timeout) — kanalga darhol ogohlantirish
- 🟡 Sayt sekin javob bersa — alohida belgilanadi
- ✅ Sayt tiklansa — "tiklandi" xabari yuboriladi
- 📋 `/list` — barcha loyihalarning joriy holatini ko'rish
- 🧑‍💻 Faqat adminlar loyiha qo'sha/o'chira oladi

## ⚙️ O'rnatish

1. Python 3.10+ o'rnatilgan bo'lishi kerak.

2. Kutubxonalarni o'rnating:
   ```bash
   pip install -r requirements.txt
   ```

3. `.env.example` faylini `.env` deb nusxalang va to'ldiring:
   ```bash
   cp .env.example .env
   ```

   - **BOT_TOKEN** — [@BotFather](https://t.me/BotFather) orqali yangi bot yarating va tokenni oling.
   - **CHANNEL_ID** — botni kanalingizga **admin** qilib qo'shing, so'ng kanal ID sini
     [@getidsbot](https://t.me/getidsbot) yoki [@userinfobot](https://t.me/userinfobot) orqali oling
     (odatda `-100` bilan boshlanadi).
   - **ADMIN_IDS** — botni boshqara oladigan shaxslarning Telegram ID'lari. O'z ID'ingizni
     bilish uchun botni ishga tushirib, unga `/id` deb yozing.

4. Botni ishga tushiring:
   ```bash
   python bot.py
   ```

## 🕹 Foydalanish

| Buyruq | Tavsif |
|---|---|
| `/start` | Botni tanishtirish + raqam ulashish tugmasi |
| `/id` | O'zingizning Telegram ID'ingizni ko'rish |
| `/add Ism \| https://sayt.uz` | Yangi loyiha qo'shish (faqat admin) |
| `/list` | Barcha loyihalar va ularning holati |
| `/check` | Hamma loyihani hoziroq qo'lda tekshirish |
| `/check_id 3` | Faqat 3-ID'li loyihani tekshirish |
| `/remove 3` | 3-ID'li loyihani o'chirish (faqat admin) |
| `/contacts` | Ro'yxatdan o'tgan raqamlar ro'yxati (faqat admin) |
| `/notify_phone +998... \| matn` | Shu raqamga bog'liq odamga shaxsiy xabar yuborish (faqat admin) |

## 📱 Telefon raqamiga xabar yuborish — MUHIM

Telegram'ning o'zi shunday ishlaydi: **hech qanday bot birovning telefon raqamiga,
o'sha odam avval botga murojaat qilmasdan, xabar yubora olmaydi.** Bu — spam'dan
himoya qilish uchun Telegram tomonidan qo'yilgan qat'iy cheklov, uni hech qanday kod
bilan chetlab o'tib bo'lmaydi.

**Shu sababli quyidagi tartib qo'shildi:**

1. Kerakli odam (masalan, +998940683221 raqami egasi) botga `/start` bosadi
2. Bot unga "📱 Raqamni ulashish" tugmasini ko'rsatadi, u bosadi
3. Bot uning raqami + Telegram ID sini bazaga saqlaydi
4. Shundan keyin siz `/notify_phone +998940683221 | Matningiz` orqali,
   yoki loyihada xato chiqqanda bot **avtomatik ravishda** o'sha raqamga xabar yuboradi

Agar bu qadamlar bajarilmasa (ya'ni odam botga umuman kirmagan bo'lsa), hech qanday
bot, hech qanday usul bilan o'sha raqamga xabar yubora olmaydi — bu texnik jihatdan
mumkin emas.

## 📦 Loyihaning tarkibi

```
loyiha_nazorat_bot/
├── bot.py          # Asosiy bot va buyruqlar
├── checker.py      # URL manzillarni tekshirish logikasi
├── db.py           # SQLite bilan ishlash
├── config.py       # Sozlamalar (.env dan o'qiydi)
├── requirements.txt
├── .env.example
└── README.md
```

## 🚀 Doimiy ishga tushirish (server uchun)

Botni serverda 24/7 ishlatish uchun `systemd` yoki `pm2`/`screen`/`tmux` dan foydalanishingiz
mumkin. Masalan, `systemd` bilan:

```ini
[Unit]
Description=Loyiha Nazorat Bot
After=network.target

[Service]
WorkingDirectory=/root/loyiha_nazorat_bot
ExecStart=/usr/bin/python3 bot.py
Restart=always
User=root

[Install]
WantedBy=multi-user.target
```

## 💡 Kengaytirish g'oyalari

- SSL sertifikat muddatini tekshirish
- Bir nechta kanalga turli loyihalarni bog'lash
- Kunlik/haftalik statistik hisobot yuborish
- Telegram bot/kanalning o'zini emas, balki serverdagi disk/CPU holatini tekshirish
